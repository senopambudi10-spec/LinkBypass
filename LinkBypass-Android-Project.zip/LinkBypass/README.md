# Link Bypass (Android)

Proyek contoh Android native dengan Kotlin. Fungsinya memeriksa redirect HTTP(S) biasa, menampilkan URL tujuan, lalu menawarkan untuk membukanya di browser.

## Batasan
- Tidak menjamin semua link bisa dilewati.
- Tidak menjalankan JavaScript situs dan tidak menangani CAPTCHA, login, token, atau proteksi anti-bot.
- Gunakan hanya untuk tautan yang boleh Anda akses.
- Pemeriksaan host publik adalah perlindungan dasar, bukan jaminan keamanan sempurna. Jangan gunakan untuk memeriksa URL yang tidak dipercaya pada jaringan sensitif.
- Aplikasi mengirim permintaan jaringan ke situs yang ditempelkan. Situs dapat mencatat permintaan tersebut.

## Cara membangun APK
1. Instal Android Studio versi stabil dan Android SDK Platform 35.
2. Ekstrak folder proyek ini.
3. Android Studio → **Open** → pilih folder `LinkBypass`.
4. Tunggu Gradle Sync selesai. Jika diminta, izinkan Android Studio mengunduh plugin/SDK dari repositori resmi.
5. Untuk mencoba: pilih perangkat/emulator lalu tekan **Run**.
6. Untuk APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.
8. Untuk rilis, gunakan **Build → Generate Signed App Bundle or APK** dan simpan keystore dengan aman.

## Struktur
- `app/src/main/java/com/example/linkbypass/MainActivity.kt` — UI dan logika pemeriksaan redirect
- `app/src/main/AndroidManifest.xml` — izin internet dan deklarasi activity
