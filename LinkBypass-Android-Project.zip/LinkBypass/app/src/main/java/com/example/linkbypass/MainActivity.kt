package com.example.linkbypass

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var input: EditText
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var resolveButton: Button
    private lateinit var openButton: Button
    private var resolvedUrl: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
            android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(20))
            setBackgroundColor(Color.WHITE)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        content.addView(TextView(this).apply {
            text = "Link Bypass"
            textSize = 28f
            setTextColor(Color.rgb(20, 30, 50))
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        content.addView(TextView(this).apply {
            text = "Periksa pengalihan tautan dan temukan alamat tujuan yang dapat diakses."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(8), 0, dp(18))
        })
        input = EditText(this).apply {
            hint = "Tempel URL https://..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            minLines = 2
            maxLines = 4
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        content.addView(input, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        resolveButton = Button(this).apply {
            text = "Periksa link"
            setOnClickListener { resolveLink() }
        }
        content.addView(resolveButton)
        status = TextView(this).apply {
            text = "Tempel tautan untuk memulai."
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(12), 0, dp(8))
        }
        content.addView(status)
        result = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(20, 30, 50))
            setTextIsSelectable(true)
            setPadding(0, dp(8), 0, dp(8))
        }
        content.addView(result)
        openButton = Button(this).apply {
            text = "Buka alamat tujuan"
            isEnabled = false
            setOnClickListener {
                val target = resolvedUrl ?: return@setOnClickListener
                startActivity(android.content.Intent(
                    android.content.Intent.ACTION_VIEW, android.net.Uri.parse(target)
                ))
            }
        }
        content.addView(openButton)
        content.addView(TextView(this).apply {
            text = "Catatan: alat ini hanya memeriksa redirect HTTP(S). Situs yang memakai JavaScript, login, CAPTCHA, token, atau proteksi anti-bot mungkin tidak dapat dilewati. Jangan gunakan untuk melewati kontrol akses."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(18), 0, 0)
        })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun resolveLink() {
        val raw = input.text.toString().trim()
        if (raw.isEmpty()) {
            input.error = "Masukkan tautan terlebih dahulu"
            return
        }
        val initial = try { URL(raw) } catch (_: Exception) {
            status.text = "URL tidak valid. Gunakan tautan lengkap https:// atau http://."
            return
        }
        if (initial.protocol !in listOf("https", "http") || initial.userInfo != null) {
            status.text = "Hanya URL HTTP/HTTPS yang didukung."
            return
        }

        resolveButton.isEnabled = false
        openButton.isEnabled = false
        resolvedUrl = null
        result.text = ""
        status.text = "Memeriksa pengalihan…"

        executor.execute {
            try {
                var current = initial
                var hops = 0
                while (true) {
                    validatePublicHost(current)
                    val connection = (current.openConnection() as HttpURLConnection).apply {
                        instanceFollowRedirects = false
                        connectTimeout = 8000
                        readTimeout = 8000
                        requestMethod = "GET"
                        setRequestProperty("User-Agent", "LinkBypass/1.0")
                        setRequestProperty("Range", "bytes=0-0")
                    }
                    val code = connection.responseCode
                    val location = connection.getHeaderField("Location")
                    connection.disconnect()

                    if (code in 300..399 && !location.isNullOrBlank()) {
                        if (hops >= 8) throw IllegalStateException("Terlalu banyak pengalihan (maksimal 8).")
                        current = URL(current, location)
                        if (current.protocol !in listOf("https", "http") || current.userInfo != null) {
                            throw IllegalStateException("Pengalihan ke skema atau URL yang tidak didukung.")
                        }
                        hops++
                    } else {
                        val finalUrl = current.toString()
                        runOnUiThread {
                            status.text = "Pemeriksaan selesai. HTTP $code · $hops pengalihan"
                            result.text = finalUrl
                            resolvedUrl = finalUrl
                            openButton.isEnabled = true
                            resolveButton.isEnabled = true
                        }
                        break
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Tidak dapat memeriksa tautan: ${e.message ?: "kesalahan jaringan"}"
                    result.text = "Coba buka tautan di browser biasa jika situs memerlukan JavaScript, login, atau verifikasi."
                    resolveButton.isEnabled = true
                }
            }
        }
    }

    private fun validatePublicHost(url: URL) {
        val host = url.host.lowercase()
        if (host.isBlank() || host == "localhost" || host.endsWith(".localhost") ||
            host.endsWith(".local") || host == "127.0.0.1" || host == "::1") {
            throw IllegalStateException("Alamat lokal tidak diizinkan.")
        }
        val addresses = InetAddress.getAllByName(host)
        if (addresses.isEmpty() || addresses.any { addr ->
                addr.isAnyLocalAddress || addr.isLoopbackAddress ||
                addr.isLinkLocalAddress || addr.isSiteLocalAddress ||
                addr.hostAddress.startsWith("fc", true) ||
                addr.hostAddress.startsWith("fd", true) ||
                addr.hostAddress.startsWith("fe80", true)
            }) {
            throw IllegalStateException("Host tidak publik atau tidak aman untuk diperiksa.")
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
